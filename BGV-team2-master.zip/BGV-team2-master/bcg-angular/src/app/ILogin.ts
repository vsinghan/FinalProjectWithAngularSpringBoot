export interface ILogin{
    "empId": number,
    "password": string,
    "roleId": number
    "empName":string
}