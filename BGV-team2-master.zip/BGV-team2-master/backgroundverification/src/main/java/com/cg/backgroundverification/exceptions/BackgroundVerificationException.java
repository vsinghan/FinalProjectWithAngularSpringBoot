package com.cg.backgroundverification.exceptions;

/**
 * custom exception class
 * 
 * @author Prakhar
 *
 */
public class BackgroundVerificationException extends Exception {

	private static final long serialVersionUID = 1L;

	public BackgroundVerificationException(String message1) {
		super(message1);

	}

}
