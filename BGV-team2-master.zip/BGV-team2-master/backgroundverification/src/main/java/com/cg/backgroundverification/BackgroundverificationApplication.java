package com.cg.backgroundverification;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BackgroundverificationApplication {

	public static void main(String[] args) {
		SpringApplication.run(BackgroundverificationApplication.class, args);
	}

}
